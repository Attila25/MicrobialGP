class ChartProps:
    def __init__(self, name, cycle_number, time):
        self.name = name
        self.cycle_number = cycle_number
        self.time = time


