class OD:
    def __init__(self, name, time, data, average, deviation_up, deviation_down):
        self.name = name
        self.time = time
        self.data = data
        self.average = average
        self.deviation_up = deviation_up
        self.deviation_down = deviation_down
