import logging

import numpy
import numpy as np
from pathlib import Path
from matplotlib import pyplot as plt
import pandas as pd
from openpyxl import load_workbook
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.linear_model import LinearRegression
from pandas.io.formats import excel

from collections import defaultdict

class GrowthRate:
    def __init__(self, name, growth_rates, time_of_max, average, deviation_up, deviation_down):
        self.name = name
        self.growth_rates = growth_rates
        self.time_of_max = time_of_max
        self.average = average
        self.deviation_up = deviation_up
        self.deviation_down = deviation_down


def create_pdf(out_folder, label):
    logging.info("Creating pdf file")
    pp = PdfPages(Path.joinpath(out_folder, 'GrowthRates_' + label + '.pdf'))
    return pp

def start_gr_calculation(label, name, time, tribe_growth_data, pp):

    logging.info("Starting Growthrate calculation of: " + label + "_" + name)
    time_of_max = {}
    growth_dict = {}

    for k, v in tribe_growth_data.items():
        growth_rate, time_slot = rolling_regression(label, name, k, time, v[1:], pp)
        if k not in growth_dict and k not in time_of_max:
            growth_dict[k] = max(growth_rate)
            time_of_max[k] = time_slot[growth_rate.index(max(growth_rate))]
        else:
            growth_dict[k].append(max(growth_rate))
            time_of_max[k].append(time_slot[growth_rate.index(max(growth_rate))])

    average = round(np.array(list(growth_dict.values())).mean(), 4)

    dev_up = round(max(growth_dict.values()) - average, 4)
    dev_down = round(average - min(growth_dict.values()), 4)

    return GrowthRate(name, growth_dict, time_of_max, average, dev_up, dev_down)


def rolling_regression(label, name, k, time, input_data, pp):

    # create rolling windows of data
    window_size = 14
    first = input_data[0]

    windows = [numpy.asarray(np.log([vals / first for vals in input_data]))[i:i + window_size] for i in range(len(input_data) - window_size + 1)]

    # fit linear regression to each window and extract growth rate
    growth_rates = []
    for window in windows:
        X = np.arange(len(window)).reshape(-1, 1)
        y = window.reshape(-1, 1)
        model = LinearRegression().fit(X, y)
        growth_rate = model.coef_[0][0]
        growth_rates.append(round(growth_rate, 4))

    # plot population data with rolling window and linear models
    plt.figure('Growth Rate of ' + label + ' ' + name + ' column: ' + k, figsize=(8, 6))

    plt.scatter(time, np.log([vals / first for vals in input_data]), alpha=0.5)
    for i in range(len(windows)):
        X = np.arange(i, i + window_size).reshape(-1, 1)
        y = windows[i].reshape(-1, 1)
        model = LinearRegression().fit(X, y)
        plt.plot(time[i:i + window_size], model.predict(X), color='red')
    plt.xlabel('Time (h)')
    plt.ylabel('Population')
    plt.title(label + ' ' + name + ' ' + k)

    gr = growth_rates
    time_s = time[window_size - 1:]

    #slope, intercept, r_value, p_value, std_err = linregress(time, np.log([vals / first for vals in input_data]))
    # Set the threshold value
    #threshold = 0.3
    # Calculate the lag time as the time it takes for the regression line to intersect the threshold value
    #lag_time = (np.log(threshold) - intercept) / slope

    pp.savefig()
    plt.close()
    return gr, time_s

def export_to_excel(out_folder, OD_growthrate_Call_list, mCh_growthrate_Call_list, yEGFP_growthrate_Call_list):

    logging.info("Generating Excel report")
    export_to_csv(out_folder, OD_growthrate_Call_list, "OD")
    export_to_csv(out_folder, mCh_growthrate_Call_list, "mCh")
    export_to_csv(out_folder, yEGFP_growthrate_Call_list, "yEGFP")

def export_to_csv(out_folder, growth_rates, label):

    logging.info("Creating csv: " + label)
    csv_path = Path.joinpath(out_folder, "Growth_rates.csv")
    excel_path = Path.joinpath(out_folder, "Growth_rates.xlsx")

    new_list = sorted(growth_rates, key=lambda x: len(x.growth_rates), reverse=True)

    for item in new_list:
        dataframe = defaultdict(list)
        for k, v in item.growth_rates.items():
            dataframe[k].append(v)
        for k, v in item.time_of_max.items():
            dataframe[k].append(v)

        dataframe["Average"].append(item.average)
        average_time = round(np.array(list(item.time_of_max.values())).mean(), 2)
        dataframe["Average"].append(average_time)

        dataframe["Deviation Up"].append(item.deviation_up)
        dev_up = round(average_time - min(item.time_of_max.values()), 2)
        dataframe["Deviation Up"].append(dev_up)

        dataframe["Deviation Down"].append(item.deviation_down)
        dev_down = round(max(item.time_of_max.values()) - average_time, 2)
        dataframe["Deviation Down"].append(dev_down)

        df = pd.DataFrame(dataframe, index=["Growth Rate", "Time"])
        new_df = pd.concat([df, pd.DataFrame(index=pd.Index(['']))])
        new_df.index.name = item.name
        new_df.to_csv(csv_path, mode='a', index = True)

    creating_excel(csv_path, excel_path, label)


def creating_excel(csv_path, excel_path, label):

    logging.info("Creating excel: " + label)
    if Path.is_file(excel_path):
        book = load_workbook(excel_path)
        writer = pd.ExcelWriter(excel_path, engine='openpyxl')
        writer.book = book
        read_file = pd.read_csv(csv_path)
        read_file.to_excel(writer, index=None, header=True, sheet_name=label)
        book.close()
        writer.close()
    else:
        read_file = pd.read_csv(csv_path)
        read_file.to_excel(excel_path, index=None, header=True, sheet_name=label)

    if Path.is_file(csv_path):
        Path.unlink(csv_path)

