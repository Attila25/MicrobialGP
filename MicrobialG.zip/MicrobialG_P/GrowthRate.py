import logging

import numpy
import numpy as np
from pathlib import Path
from matplotlib import pyplot as plt
import pandas as pd
from openpyxl import load_workbook
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.linear_model import LinearRegression
from scipy.stats import linregress

from pandas.io.formats import excel

from collections import defaultdict

class GrowthRate:
    def __init__(self, name, growth_rates, time_of_max, average, avg_time, deviation_up, deviation_down):
        self.name = name
        self.growth_rates = growth_rates
        self.time_of_max = time_of_max
        self.average = average
        self.avg_time = avg_time
        self.deviation_up = deviation_up
        self.deviation_down = deviation_down


def create_pdf_p1(out_folder, label):
    logging.info("Creating pdf file")
    pp = PdfPages(Path.joinpath(out_folder, 'GrowthRates_' + label + '.pdf'))
    return pp

def start_gr_calculation_p1(label, name, time, tribe_growth_data, pp):

    logging.info("Starting Growthrate calculation of: " + label + "_" + name)
    time_of_max = {}
    growth_dict = {}

    for k, v in tribe_growth_data.items():
        growth_rate, time_slot = rolling_regression_p1(label, name, k, time, v[1:], pp)
        if k not in growth_dict and k not in time_of_max:
            growth_dict[k] = max(growth_rate)
            time_of_max[k] = time_slot[growth_rate.index(max(growth_rate))]
        else:
            growth_dict[k].append(max(growth_rate))
            time_of_max[k].append(time_slot[growth_rate.index(max(growth_rate))])

    average = round(np.array(list(growth_dict.values())).mean(), 4)
    avg_time = round(np.array(list(time_of_max.values())).mean(), 4)

    dev_up = round(max(growth_dict.values()) - average, 4)
    dev_down = round(average - min(growth_dict.values()), 4)

    return GrowthRate(name, growth_dict, time_of_max, average, avg_time, dev_up, dev_down)


def rolling_regression_p1(label, name, k, time, input_data, pp):

    #Smoothing data using exponential moving average
    df = pd.DataFrame(input_data)
    alpha = 0.3
    df['Moving_Avg'] = round(df.ewm(alpha=alpha).mean(), 4)
    input_data = df['Moving_Avg'].tolist()

    #identifying exponential phase
    start_index, end_index = find_exponential_phase(input_data)

    input_data = input_data[start_index:end_index]
    time = time[start_index:end_index]
    first = input_data[0]

    # create rolling windows of data
    window_size = 5
    windows = [numpy.asarray(np.log([round(vals / first, 6) for vals in input_data]))[i:i + window_size] for i in range(len(input_data) - window_size + 1)]

    # fit linear regression to each window and extract growth rate
    growth_rates = []
    for window in windows:
        X = np.arange(len(window)).reshape(-1, 1)
        y = window.reshape(-1, 1)
        model = LinearRegression().fit(X, y)
        growth_rate = model.coef_[0][0]
        growth_rates.append(round(growth_rate, 4))

    # plot population data with rolling window and linear models
    plt.figure('Growth Rate of ' + label + ' ' + name + ' column: ' + k, figsize=(8, 6))

    plt.scatter(time, np.log([vals / first for vals in input_data]), alpha=0.5)
    for i in range(len(windows)):
        X = np.arange(i, i + window_size).reshape(-1, 1)
        y = windows[i].reshape(-1, 1)
        model = LinearRegression().fit(X, y)
        plt.plot(time[i:i + window_size], model.predict(X), color='red')
    plt.xlabel('Time (h)')
    plt.ylabel('Population')
    plt.title(label + ' ' + name + ' ' + k)

    gr = growth_rates
    time_s = time[window_size - 1:]

    #slope, intercept, r_value, p_value, std_err = linregress(time, np.log([vals / first for vals in input_data]))
    # Set the threshold value
    #threshold = 0.3
    # Calculate the lag time as the time it takes for the regression line to intersect the threshold value
    #lag_time = (np.log(threshold) - intercept) / slope

    pp.savefig()
    plt.close()
    return gr, time_s

def export_to_excel(out_folder, OD_growthrate_Call_list, mCh_growthrate_Call_list, yEGFP_growthrate_Call_list, green_fluor, red_flour, only_OD):

    logging.info("Generating Excel report")
    export_to_csv(out_folder, OD_growthrate_Call_list, "OD")
    if not only_OD:
        export_to_csv(out_folder, mCh_growthrate_Call_list, red_flour)
        export_to_csv(out_folder, yEGFP_growthrate_Call_list, green_fluor)

def export_to_csv(out_folder, growth_rates, label):

    logging.info("Creating csv: " + label)
    csv_path = Path.joinpath(out_folder, "Growth_rates.csv")
    excel_path = Path.joinpath(out_folder, "Growth_rates.xlsx")

    new_list = sorted(growth_rates, key=lambda x: len(x.growth_rates), reverse=True)

    for item in new_list:
        dataframe = defaultdict(list)
        for k, v in item.growth_rates.items():
            dataframe[k].append(v)
        for k, v in item.time_of_max.items():
            dataframe[k].append(v)

        dataframe["Average"].append(item.average)
        average_time = round(np.array(list(item.time_of_max.values())).mean(), 2)
        dataframe["Average"].append(average_time)

        dataframe["Deviation Up"].append(item.deviation_up)
        dev_up = round(average_time - min(item.time_of_max.values()), 2)
        dataframe["Deviation Up"].append(dev_up)

        dataframe["Deviation Down"].append(item.deviation_down)
        dev_down = round(max(item.time_of_max.values()) - average_time, 2)
        dataframe["Deviation Down"].append(dev_down)

        df = pd.DataFrame(dataframe, index=["Growth Rate", "Time"])
        new_df = pd.concat([df, pd.DataFrame(index=pd.Index(['']))])
        new_df.index.name = item.name
        new_df.to_csv(csv_path, mode='a', index = True)

    creating_excel(csv_path, excel_path, label)


def creating_excel(csv_path, excel_path, label):

    logging.info("Creating excel: " + label)
    if Path.is_file(excel_path):
        book = load_workbook(excel_path)
        writer = pd.ExcelWriter(excel_path, engine='openpyxl')
        writer.book = book
        read_file = pd.read_csv(csv_path)
        read_file.to_excel(writer, index=None, header=True, sheet_name=label)
        book.close()
        writer.close()
    else:
        read_file = pd.read_csv(csv_path)
        read_file.to_excel(excel_path, index=None, header=True, sheet_name=label)

    if Path.is_file(csv_path):
        Path.unlink(csv_path)


def find_exponential_phase(growth_data, threshold_start = 0.085, threshold_end=0.03, window_size=7):
    """
    Identify the exponential growth phase in OD data.

    Parameters:
    - od_data: Pandas Series or NumPy array containing optical density data.
    - threshold: Slope threshold for identifying exponential growth.
    - window_size: Number of data points to use in the rolling regression.

    Returns:
    - Tuple (start_index, end_index) representing the indices of the exponential phase.
    """
    # Calculate the logarithm of the OD data
    log_od = np.log(growth_data)

    # Initialize variables
    start_index = 0
    end_index = len(growth_data)

    slope_array = []

    # Iterate through the data with a rolling window
    for i in range(len(growth_data) - window_size + 1):
        window_data = log_od[i:i+window_size]
        time_points = np.arange(i, i+window_size)
        # Perform linear regression on the log-transformed data
        slope, _, _, _, _ = linregress(time_points, window_data)
        slope_array.append(slope)
        # Check if the slope exceeds the threshold
        if slope > threshold_start and i > window_size:
            if slope_array[i-window_size] > 0:
                start_index = i
                break
    slope_array = []
    # Reverse iteration to find the end of the exponential phase
    for i in range(len(growth_data) - 1, start_index, -1):
        window_data = log_od[i-window_size+1:i+1]
        time_points = np.arange(i-window_size+1, i+1)
        if len(window_data) != 0:
            # Perform linear regression on the log-transformed data
            slope, _, _, _, _ = linregress(time_points, window_data)
            slope_array.append(slope)
            # Check if the slope drops below the threshold
            if slope > threshold_end and i < (len(growth_data) - window_size):
                if slope_array[len(growth_data) - i - window_size] > 0:
                    end_index = i
                    break

    return start_index, end_index
'''
# Example usage:
# Assuming 'time' is your time data and 'od' is your optical density data
# Replace these with the actual names of your columns or variables
time = np.arange(1, 101)  # Replace with your actual time data
od = np.exp(0.1 * time) + np.random.normal(0, 0.1, size=len(time))  # Replace with your actual OD data

# Create a DataFrame with time and OD columns
data = pd.DataFrame({'time': time, 'od': od})

# Find the exponential phase indices
start_idx, end_idx = find_exponential_phase(data['od'])

# Plot the data with the identified exponential phase
plt.plot(data['time'], data['od'], label='OD Data')
plt.axvspan(data['time'][start_idx], data['time'][end_idx], color='orange', alpha=0.5, label='Exponential Phase')
plt.xlabel('Time')
plt.ylabel('OD')
plt.legend()
plt.show()
'''
