import logging
import os
import re

from pathlib import Path
import pandas as pd
import openpyxl as opx
import json
import sys
import re
import multiprocessing
from collections import defaultdict

from OD import OD
from mCh import mCh
from yEGFP import yEGFP
from ChartProps import ChartProps
import GrowthRate as GR


def get_input_arguments():

    input_data_xlsx = sys.argv[1]
    input_layout_xlsx = sys.argv[2]
    output_folder = sys.argv[3]

    dt = Datahandler(input_data_xlsx, input_layout_xlsx, output_folder)
    dt.excel_data_to_csv()
    dt.fill_layout_table()
    dt.fill_data_classes()
    dt.to_json()
    dt.cleanup()


class Datahandler:
    def __init__(self, input_data_xlsx, input_layout_xlsx, output_folder):
        self.input_data_xlsx = input_data_xlsx
        self.input_layout_xlsx = input_layout_xlsx
        self.date_of_measure = str(re.search(r'\d{4}\d{2}\d{2}', self.input_data_xlsx).group(0))
        self.output_folder = Path(output_folder, self.date_of_measure)
        self.input_csv_name = Path(self.output_folder, self.input_data_xlsx.replace('xlsx', 'csv'))
        self.input_layout_name = Path(self.output_folder, self.input_data_xlsx.replace('.xlsx', '_Layout.csv'))
        self.input_key_name = Path(self.output_folder, self.input_data_xlsx.replace('.xlsx', '_Key.csv'))
        self.layout_key_pair_dict = defaultdict(list)
        self.OD_Class_list = []
        self.mCh_Class_list = []
        self.yEGFP_Class_list = []
        self.OD_growthrate_Class_list = []
        self.mCh_growthrate_Class_list = []
        self.yEGFP_growthrate_Class_list = []
        self.green_fluor = None
        self.red_flour = None
        self.chart_props = None
        logging.basicConfig(filename="runtimelog",
                            filemode='a',
                            format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
                            datefmt='%H:%M:%S',
                            level=logging.DEBUG)

        Path(self.output_folder).mkdir(parents=True, exist_ok=True)

    def excel_data_to_csv(self):
        logging.info("Converting excel data to csv")
        data_file = pd.read_excel(self.input_data_xlsx, index_col=None)
        data_file.to_csv(self.input_csv_name, encoding="utf-8", index_label=None, index=False, sep=";")

    def fill_layout_table(self):
        logging.info("Creating layout table")
        layout_file = pd.read_excel(self.input_layout_xlsx, sheet_name="Layout", index_col=None)
        key_file = pd.read_excel(self.input_layout_xlsx, sheet_name="Key", index_col=None)

        layout_file.to_csv(self.input_layout_name, encoding="utf-8", index_label=None, index=False, sep=";")
        key_file.to_csv(self.input_key_name, encoding="utf-8", index_label=None, index=False, sep=";")

        logging.info("Parsing the layout of the measurement")
        layout_list = []
        with open(self.input_layout_name, "r") as layout_file:
            layout_file.readline()
            index = 1
            for line in layout_file:
                line = line.rstrip()
                id = line.split(";")[0]
                for i in range(1, len(line.split(";"))):
                    layout_list.append(id + str(index) + ";" + line.split(";")[i])
                    index = index + 1
                index = 1
            layout_file.close()

        logging.info("Parsing the keys of the measurement")
        key_list = []
        with open(self.input_key_name, "r") as key_file:
            for line in key_file:
                line = line.rstrip()
                key_list.append(line)
            key_file.close()

        logging.info("Creating the dictionary of the tribes")
        for key_items in key_list:
            id = key_items.split(";")[0]
            name = key_items.split(";")[1]

            for layout_items in layout_list:
                if layout_items.split(";")[1] == id:
                    self.layout_key_pair_dict[name].append(layout_items.split(";")[0])

    def fill_data_classes(self):

        logging.info("Creating the Data tables")
        list_for_time = []
        list_for_OD = []
        list_for_mCh = []
        list_for_yEGFP = []
        check_class = ""

        with open(self.input_csv_name, "r") as datafile:
            logging.info("Reading the Data csv")
            for line in datafile:
                if check_class == "OD" and not line.startswith(";") and line.split(";")[0] not in ["mCh", "RFP"]:
                    list_for_OD.append(line.strip())
                elif check_class == self.red_flour and not line.startswith(";") and line.split(";")[0] not in ["yEGFP", "YFP"]:
                    list_for_mCh.append(line.strip())
                elif check_class == self.green_fluor and not line.startswith(";") and "End" not in line.split(";")[0]:
                    list_for_yEGFP.append(line.strip())

                if "OD" in line.split(";")[0]:
                    check_class = "OD"

                for item in ["yEGFP", "YFP"]:
                    if item in line.split(";")[0]:
                        check_class = item if "GFP" not in item else "GFP"
                        self.green_fluor = item if "GFP" not in item else "GFP"

                for item in ["mCh", "RFP"]:
                    if item in line.split(";")[0]:
                        check_class = item
                        self.red_flour = item

                if "End" in line.split(";")[0]:
                    check_class = "Done"

        logging.info("Reforming the data to the valid structure")
        first_line = list_for_OD[0]

        list_for_OD.pop(0)
        list_for_mCh.pop(0)
        list_for_yEGFP.pop(0)

        for items in list_for_OD:
            meastime = float(items.split(";")[1]) / 60
            list_for_time.append(round(meastime/60, 2))

        logging.info("Creating and filling the classes")
        for k, v in self.layout_key_pair_dict.items():
            OD_data = defaultdict(list)
            mCh_data = defaultdict(list)
            yEGFP_data = defaultdict(list)

            logging.info("Reading the data values")
            for data in v:
                col = first_line.split(";").index(data)
                for items in list_for_OD:
                    OD_data[data].append(float(items.split(";")[col]))
                for items in list_for_mCh:
                    mCh_data[data].append(float(items.split(";")[col]))
                for items in list_for_yEGFP:
                    yEGFP_data[data].append(float(items.split(";")[col]))

            OD_average = [round(sum(vals) / len(vals), 4) for vals in zip(*OD_data.values())]
            mCh_average = [round(sum(vals) / len(vals), 4) for vals in zip(*mCh_data.values())]
            yEGFP_average = [round(sum(vals) / len(vals), 4) for vals in zip(*yEGFP_data.values())]

            logging.info("Adding the new values to the class")
            self.OD_Class_list.append(OD(k, 0, OD_data, OD_average, [], []))
            self.mCh_Class_list.append(mCh(k, 0, mCh_data, mCh_average, [], []))
            self.yEGFP_Class_list.append(yEGFP(k, 0, yEGFP_data, yEGFP_average, [], []))

            logging.info("Processing of " + k + " finished")

        logging.info("Substracting the background values")
        Background_values_OD = [x.average for x in self.OD_Class_list if x.name.casefold() == "Background".casefold()]
        Background_values_mCh = [x.average for x in self.mCh_Class_list if x.name.casefold() == "Background".casefold()]
        Background_values_yEGFP = [x.average for x in self.yEGFP_Class_list if x.name.casefold() == "Background".casefold()]

        logging.info("Calculating Growth rate of OD")

        queue1 = multiprocessing.Queue()
        queue2 = multiprocessing.Queue()
        queue3 = multiprocessing.Queue()

        p1 = multiprocessing.Process(target=self.calc_growth_rate_OD, args=("OD", self.OD_Class_list, list_for_time, Background_values_OD, queue1))
        p2 = multiprocessing.Process(target=self.calc_growth_rate_RED, args=(self.red_flour, self.mCh_Class_list, list_for_time, Background_values_mCh, queue2))
        p3 = multiprocessing.Process(target=self.calc_growth_rate_GREEN, args=(self.green_fluor, self.yEGFP_Class_list, list_for_time, Background_values_yEGFP, queue3))

        p1.start()
        p2.start()
        p3.start()

        result1 = queue1.get()
        result2 = queue2.get()
        result3 = queue3.get()

        p1.join()
        p2.join()
        p3.join()

        self.OD_growthrate_Class_list = result1[0]
        self.mCh_growthrate_Class_list = result2[0]
        self.yEGFP_growthrate_Class_list = result3[0]

        self.OD_Class_list = result1[1]
        self.mCh_Class_list = result2[1]
        self.yEGFP_Class_list = result3[1]

        Cycle_number = len(*Background_values_OD)
        self.chart_props = ChartProps(self.date_of_measure, Cycle_number, list_for_time)

        logging.info("Creating Excel containing the growth rates")
        GR.export_to_excel(self.output_folder, self.OD_growthrate_Class_list, self.mCh_growthrate_Class_list, self.yEGFP_growthrate_Class_list, self.green_fluor, self.red_flour)

    def calc_growth_rate_OD(self, id, OD_proc_list, list_for_time, Background_values_OD, q):

        OD_growthrate_list = []

        pp = GR.create_pdf_p1(self.output_folder, id)
        for datas in OD_proc_list:
            invalid_tribe_data = ""
            for k, v in datas.data.items():
                new_values = [abs(round(a - b, 4) if a - b != 0 else 0.0001) for a, b in zip(v, *Background_values_OD)]
                if datas.name.casefold() != "Background".casefold():
                    datas.data[k] = new_values
                if datas.data[k][-1] < 0.05:
                    invalid_tribe_data = k
            if invalid_tribe_data != "":
                del datas.data[invalid_tribe_data]

            if datas.name.casefold() != "Background".casefold():
                OD_growthrate_list.append(
                    GR.start_gr_calculation_p1("OD", datas.name, list_for_time[1:], datas.data, pp))

            datas.average = [round(sum(vals) / len(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_up = [round(max(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_down = [round(min(vals), 4) for vals in zip(*datas.data.values())]
        pp.close()

        q.put([OD_growthrate_list, OD_proc_list])

    def calc_growth_rate_RED(self, id, mCh_proc_list, list_for_time, Background_values_mCh, q):

        logging.info("Calculating Growth rate of " + id)
        mCh_growthrate_list = []

        pp = GR.create_pdf_p1(self.output_folder, id)
        for datas in mCh_proc_list:
            for k, v in datas.data.items():
                new_values = [abs(round(a - b, 4) if a - b != 0 else 0.0001) for a, b in zip(v, *Background_values_mCh)]
                if datas.name.casefold() != "Background".casefold():
                    datas.data[k] = new_values

            if id in datas.name:
                mCh_growthrate_list.append(
                    GR.start_gr_calculation_p1(id, datas.name, list_for_time[1:], datas.data, pp))

            datas.average = [round(sum(vals) / len(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_up = [round(max(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_down = [round(min(vals), 4) for vals in zip(*datas.data.values())]
        pp.close()

        q.put([mCh_growthrate_list, mCh_proc_list])

    def calc_growth_rate_GREEN(self, id, yEGFP_proc_list, list_for_time, Background_values_yEGFP, q):

        logging.info("Calculating Growth rate of " + id)
        yEGFP_growthrate_list = []

        pp = GR.create_pdf_p1(self.output_folder, id)
        for datas in yEGFP_proc_list:
            for k, v in datas.data.items():
                new_values = [abs(round(a - b, 4) if a - b != 0 else 0.0001) for a, b in
                              zip(v, *Background_values_yEGFP)]
                if datas.name.casefold() != "Background".casefold():
                    datas.data[k] = new_values

            if id in datas.name:
                yEGFP_growthrate_list.append(
                    GR.start_gr_calculation_p1(id, datas.name, list_for_time[1:], datas.data, pp))

            datas.average = [round(sum(vals) / len(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_up = [round(max(vals), 4) for vals in zip(*datas.data.values())]
            datas.deviation_down = [round(min(vals), 4) for vals in zip(*datas.data.values())]
        pp.close()

        q.put([yEGFP_growthrate_list, yEGFP_proc_list])

    def obj_dict(self, obj):
        return obj.__dict__

    def to_json(self):
        logging.info("Creating JSON format")
        with open(Path.joinpath(self.output_folder, 'OD_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.OD_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, self.red_flour + '_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.mCh_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, self.green_fluor + '_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.yEGFP_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, 'ChartProps_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.chart_props, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, 'OD_Growthrate_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.OD_growthrate_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, self.red_flour + '_Growthrate_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.mCh_growthrate_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

        with open(Path.joinpath(self.output_folder, self.green_fluor + '_Growthrate_' + self.date_of_measure + '.json'), 'w', encoding='utf-8') as f:
            json.dump(self.yEGFP_growthrate_Class_list, f, ensure_ascii=False, indent=4, default=self.obj_dict)

    def cleanup(self):
        logging.info("Deleting unnecessary  files")
        if Path.is_file(self.input_csv_name):
            Path.unlink(self.input_csv_name)

        if Path.is_file(self.input_key_name):
            Path.unlink(self.input_key_name)

        if Path.is_file(self.input_layout_name):
            Path.unlink(self.input_layout_name)

        print(str(self.output_folder))

if __name__ == '__main__':
    get_input_arguments()